package com.test.dell.project;

import android.content.Intent;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity
{
    EditText ed1;
    EditText ed2;
    EditText ed3;
    String s1;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=(EditText)findViewById(R.id.user);
        ed2=(EditText)findViewById(R.id.mail);
        ed3=(EditText)findViewById(R.id.pass);
        RadioButton rb1 = (RadioButton)findViewById(R.id.rb1);
        if(rb1.isChecked())
        {
            s1="male";
        }
        else
        {
            s1="female";
        }

    }
    public void signUp(View v)
    {
        Intent in = new Intent(MainActivity.this,LoginActivity.class);
        in.putExtra("username",ed1.getText().toString());
        in.putExtra("email",ed2.getText().toString());
        in.putExtra("password",ed3.getText().toString());
        in.putExtra("gender",s1);
        startActivity(in);
    }
}
