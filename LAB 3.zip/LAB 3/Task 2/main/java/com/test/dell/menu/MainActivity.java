package com.test.dell.menu;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity
{
    EditText ed1;
    Button call;
    Button cam;
    Button cont;
    Button brow;
    Button gall;
    Button log;
    Button pad;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.text);
        call=findViewById(R.id.call);
        cam=findViewById(R.id.cam);
        cont=findViewById(R.id.cont);
        brow=findViewById(R.id.brow);
        gall=findViewById(R.id.gall);
        log=findViewById(R.id.log);
        pad=findViewById(R.id.pad);

    }
    public void setCall(View view)
    {
        Intent in = new Intent(Intent.ACTION_CALL);
        in.setData(Uri.parse("tel:"+ed1.getText().toString()));
        startActivity(in);
    }
    public void setCam(View view)
    {
        Intent in = new Intent(Intent.ACTION_CAMERA_BUTTON);
        startActivity(in);
    }
    public void setCont(View view)
    {
        Intent in = new Intent(Intent.ACTION_VIEW);
        in.setData(Uri.parse("content://contacts/people/"));
        startActivity(in);
    }
    public void setBrow(View view)
    {
        Intent in = new Intent(Intent.ACTION_VIEW);
        in.setData(Uri.parse(ed1.getText().toString()));
        startActivity(in);
    }
    public void setGall(View view)
    {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse("content://media/external/images/media/"));
        startActivity(i);

    }
    public void setLog(View view)
    {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse("content://call_log/calls/1"));
        startActivity(i);

    }
    public void setPad(View view)
    {
        Intent i = new Intent(Intent.ACTION_DIAL);
        i.setData(Uri.parse("tel:"+ed1.getText().toString()));
        startActivity(i);

    }
}
