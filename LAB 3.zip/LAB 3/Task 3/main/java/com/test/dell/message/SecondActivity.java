package com.test.dell.message;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class SecondActivity extends AppCompatActivity
{

    EditText ed1;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        ed1=findViewById(R.id.editText);
    }
    public void sendMessage(View v)
    {
        Intent i = new Intent(SecondActivity.this,MainActivity.class);
        i.putExtra("msg",ed1.getText().toString());
        startActivity(i);
    }
}
