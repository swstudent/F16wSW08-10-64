package com.test.dell.gestures;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import static android.view.MotionEvent.actionToString;

public class MainActivity extends AppCompatActivity implements GestureDetector.OnGestureListener,
        ScaleGestureDetector.OnScaleGestureListener
{

    GestureDetectorCompat gestureDetectorCompat;
    ImageView gesture;
    static int checkId=0;
    float scale = 1.0f;
    //float onScaleBegin = 0.0f;
    //String TAG = "ABC";
    private ScaleGestureDetector detector;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gesture=findViewById(R.id.imageView);
        gesture.setImageResource(R.drawable.abida);
        gestureDetectorCompat=new GestureDetectorCompat(this,this);
        detector =new ScaleGestureDetector(this,this);
        gestureDetectorCompat.setIsLongpressEnabled(true);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
         gestureDetectorCompat.onTouchEvent(event);
         detector.onTouchEvent(event);
         return super.onTouchEvent(event);
    }

    @Override
    public boolean onDown(MotionEvent e) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY)
    {
        if(e2.getX()>e1.getX())
        {
            //Toast.makeText(getApplicationContext(),"Right fling",Toast.LENGTH_SHORT).show();
            if(checkId<=3)
            {
                checkId+=1;
                if(checkId==3) checkId = 0;
                if(checkId==-1) checkId = 2;

                if (checkId == 0 )
                    gesture.setImageResource(R.drawable.abida);
                if (checkId == 1)
                    gesture.setImageResource(R.drawable.natu);
                if (checkId == 2)
                    gesture.setImageResource(R.drawable.murk);
            }

        }
        if(e2.getX()<e1.getX())
        {
            //Toast.makeText(getApplicationContext(),"Left fling",Toast.LENGTH_SHORT).show();
            if(checkId>=-1)
            {
                checkId -= 1;
                if(checkId==3) checkId = 0;
                if(checkId==-1) checkId = 2;

                if (checkId == 0)
                    gesture.setImageResource(R.drawable.abida);
                if (checkId == 1)
                    gesture.setImageResource(R.drawable.natu);
                if (checkId == 2)
                    gesture.setImageResource(R.drawable.murk);

            }
        }
        return false;
    }


    @Override
    public boolean onScale(ScaleGestureDetector detector) {
        scale *= detector.getScaleFactor();
        gesture.setScaleX(scale);
        gesture.setScaleY(scale);
        return true;
    }

    @Override
    public boolean onScaleBegin(ScaleGestureDetector detector) {
        return true;
    }

    @Override
    public void onScaleEnd(ScaleGestureDetector detector) {

    }
}
