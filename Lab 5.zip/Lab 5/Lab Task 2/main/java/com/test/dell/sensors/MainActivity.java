package com.test.dell.sensors;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements SensorEventListener
{

    private SensorManager mSensorManager;
    ImageView imageView;
    Sensor sensor;
    int width=132*2,height=198*2;
    ConstraintLayout cl;
    ConstraintLayout.LayoutParams params;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cl = findViewById(R.id.cl1);
        imageView = findViewById(R.id.imageView);
        params = (ConstraintLayout.LayoutParams) imageView.getLayoutParams();
        cl.requestLayout();
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensor =mSensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        mSensorManager.registerListener(this, sensor,SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        mSensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event)
    {
        if(event.values[0] < sensor.getMaximumRange())
        {
//            imageView.getLayoutParams().width=width*2;
//            imageView.getLayoutParams().height=height*2;
//            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            params.width=width*2;
            params.height=height*2;
            imageView.setLayoutParams(params);

            //Toast.makeText(getApplicationContext(),width+" "+height+"\n"+width*2+" "+height*2,Toast.LENGTH_SHORT).show();
        }
        else
        {
//            imageView.getLayoutParams().width=width;
//            imageView.getLayoutParams().height=height;
//            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            params.width=width;
            params.height=height;
            imageView.setLayoutParams(params);

        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy)
    {

    }

}
