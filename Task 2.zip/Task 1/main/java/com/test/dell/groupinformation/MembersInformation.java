package com.test.dell.groupinformation;

import android.content.Intent;
import android.support.annotation.DrawableRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MembersInformation extends AppCompatActivity
{
    static String info[][] = new String[][]{{"Abida Parveen","F16SW08","abida.parveen840@gmail.com"},{"Natasha","F16SW64","natasha.afaque@gamil.com"},{"Murk","F16SW10","murk.sheikh@gmail.com"}};
    static int checkId=0;
    TextView tv1;
    TextView tv2;
    TextView tv3;
    ImageView iv;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_members_information);
        iv = (ImageView)findViewById(R.id.imageView);
        tv1 = (TextView)findViewById(R.id.textView);
        tv2 = (TextView)findViewById(R.id.textView2);
        tv3 = (TextView)findViewById(R.id.textView3);
        tv1.setText(info[checkId][0]);
        tv2.setText(info[checkId][1]);
        tv3.setText(info[checkId][2]);

    }
    public void next(View v)
    {
        if(checkId<=2)
        {
            checkId += 1;

            tv1.setText(info[checkId][0]);
            tv2.setText(info[checkId][1]);
            tv3.setText(info[checkId][2]);
            if (checkId == 1)
                iv.setImageResource(R.drawable.murk);
            if (checkId == 2)
                iv.setImageResource(R.drawable.natu);
            if(checkId==0)
                iv.setImageResource(R.drawable.abida);
        }
    }
    public void previous(View v)
    {
        if(checkId>=0)
        {
            checkId -= 1;

            tv1.setText(info[checkId][0]);
            tv2.setText(info[checkId][1]);
            tv3.setText(info[checkId][2]);
            if (checkId == 1)
                iv.setImageResource(R.drawable.murk);
            if (checkId == 2)
                iv.setImageResource(R.drawable.natu);
            if(checkId==0)
                iv.setImageResource(R.drawable.abida);
        }
    }
}
