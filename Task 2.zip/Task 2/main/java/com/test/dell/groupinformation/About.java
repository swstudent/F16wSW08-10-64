package com.test.dell.groupinformation;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class About extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        TextView tv = (TextView)findViewById(R.id.textView4);
        tv.setText("This is lab task 2 done by \n Abida (F16SW08) \n Natasha Afaque (F16SW64) \n Murk Sheikh (F16SW10)");
    }
}
