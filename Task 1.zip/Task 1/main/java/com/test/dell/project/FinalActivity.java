package com.test.dell.project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class FinalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);
        TextView tv =(TextView)findViewById(R.id.textView);
        TextView tv2 =(TextView)findViewById(R.id.textView2);
        TextView tv3 =(TextView)findViewById(R.id.textView3);
        Intent in = getIntent();
        String s = in.getStringExtra("name");
        String s2= in.getStringExtra("mail");
        String s3= in.getStringExtra("gender");
        tv.setText(s);
        tv2.setText(s2);
        tv3.setText(s3);
    }
}
