package com.test.dell.project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity
{
    EditText e1;
    EditText e2;
    String s1;
    String s2;
    String s3;
    String gender;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        e1=(EditText)findViewById(R.id.editText);
        e2=(EditText)findViewById(R.id.editText3);
        Intent in = getIntent();
        s1=in.getStringExtra("username");
        s2=in.getStringExtra("password");
        s3=in.getStringExtra("email");
        gender=in.getStringExtra("gender");
    }
    public void logIn(View v)
    {
        String user=e1.getText().toString();
        String pass=e2.getText().toString();
        if(s1.equals(user)&&s2.equals(pass))
        {
            Intent in = new Intent(LoginActivity.this,FinalActivity.class);
            in.putExtra("name",e1.getText().toString());
            in.putExtra("mail",s3);
            in.putExtra("gender",gender);
            startActivity(in);
        }

    }
}
