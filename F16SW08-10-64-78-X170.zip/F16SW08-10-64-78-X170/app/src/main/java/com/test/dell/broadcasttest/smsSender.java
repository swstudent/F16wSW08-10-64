package com.test.dell.broadcasttest;

import android.telephony.SmsManager;

public class smsSender {

    static String num = null;
   static String mess = null;

    public static void smsSendCall(String no,String message)
    {

        num = no;
        mess = message;

        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(num, null, mess, null, null);

    }
}
