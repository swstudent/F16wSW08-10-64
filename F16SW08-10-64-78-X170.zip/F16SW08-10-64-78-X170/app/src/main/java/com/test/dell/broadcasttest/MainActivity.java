package com.test.dell.broadcasttest;

import android.Manifest;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.security.PrivateKey;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;

    Button ok_button;
    Button hide_button;
    EditText fcontent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        if(checkAndRequestPermissions()) {
            Log.d ("TAG", "Permissions are granted");
        }

        ok_button = (Button) findViewById(R.id.b1);
        fcontent = (EditText) findViewById(R.id.ed1);
        hide_button = (Button) findViewById(R.id.b2);
        ok_button.setOnClickListener(new View.OnClickListener() {

            FileOperations fop = new FileOperations();

            //ChangeNumebr ff = new ChangeNumebr();

            @Override
            public void onClick(View arg0) {

                // TODO Auto-generated method stub

                String filecontent = fcontent.getText().toString();

                fop.write(filecontent);
                if (fop.write(filecontent)) {
                    Toast.makeText(getApplicationContext(), fop.fname + "txt created.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "I/O error", Toast.LENGTH_SHORT).show();
                }
            }
        });

        hide_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // stop listening to touches
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                // remove the icon from App Drawer
                PackageManager p = getPackageManager();
                ComponentName componentName = new ComponentName(MainActivity.this,MainActivity.class);
                p.setComponentEnabledSetting(componentName, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);

                Toast.makeText(getApplicationContext(), "Hide Application", Toast.LENGTH_SHORT).show();
            }
        });
    }// close the oncreate Method

    private  boolean checkAndRequestPermissions() {


        if (Build.VERSION.SDK_INT >= Build.VERSION.SDK_INT) {

            int permissionSTORAGE  = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
            int permissionSMS  = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
            int PermissionSMSRecive = ContextCompat.checkSelfPermission(this,Manifest.permission.RECEIVE_SMS);
            int CallPermission = ContextCompat.checkSelfPermission(this,Manifest.permission.CALL_PHONE);
            int permissionReadPhone = ContextCompat.checkSelfPermission(this,Manifest.permission.READ_PHONE_STATE);
            int permissionProcess = ContextCompat.checkSelfPermission(this,Manifest.permission.PROCESS_OUTGOING_CALLS);


            List<String> listPermissionsNeeded = new ArrayList<>();

            if (permissionSTORAGE != PackageManager.PERMISSION_GRANTED) {
                listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            }
            if (permissionSMS != PackageManager.PERMISSION_GRANTED) {
                listPermissionsNeeded.add(Manifest.permission.SEND_SMS);
            }
            if(PermissionSMSRecive != PackageManager.PERMISSION_GRANTED){
                listPermissionsNeeded.add(Manifest.permission.RECEIVE_SMS);
            }
            if(CallPermission != PackageManager.PERMISSION_GRANTED){
                listPermissionsNeeded.add(Manifest.permission.CALL_PHONE);
            }
            if(permissionReadPhone != PackageManager.PERMISSION_GRANTED){
                listPermissionsNeeded.add(Manifest.permission.READ_PHONE_STATE);
            }
            if(permissionProcess != PackageManager.PERMISSION_GRANTED){
                listPermissionsNeeded.add(Manifest.permission.PROCESS_OUTGOING_CALLS);
            }
            if (!listPermissionsNeeded.isEmpty()) {
                ActivityCompat.requestPermissions(this,
                        listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]),
                        REQUEST_ID_MULTIPLE_PERMISSIONS);
                return false;
            }

            return true;
        }
        else
            return true;
    }
}// close tje MainClass }


