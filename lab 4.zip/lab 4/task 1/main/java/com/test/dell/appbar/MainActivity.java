package com.test.dell.appbar;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.design.widget.AppBarLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
{

    ListView lv;
    ArrayList<String> listItem;
    static ArrayAdapter<String> adapter;
    static int postionINDEX;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.inflateMenu(R.menu.menu_main);
        setSupportActionBar(toolbar);
        getSupportActionBar().setLogo(R.drawable.ic_search);
        lv=findViewById(R.id.listView);
        registerForContextMenu(lv);

        listItem = new ArrayList<String>();
        for(int i=1;i<=50;i++)
        {
            listItem.add("Samsung "+i);
        }
        adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, listItem);

        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                String value = lv.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(), value , Toast.LENGTH_SHORT).show();
                postionINDEX=position;

            }
        });
        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id)
            {
                postionINDEX=position;
                return false;
            }
        });
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Main Page");
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.action_search:
                Toast.makeText(getApplicationContext(),item.getTitle(),
                        Toast.LENGTH_LONG).show();
                return true;
            case R.id.action_info:
                Toast.makeText(getApplicationContext(),item.getTitle(),
                        Toast.LENGTH_LONG).show();
                return true;
            case R.id.action_settings:
                Toast.makeText(getApplicationContext(),item.getTitle(),
                        Toast.LENGTH_LONG).show();
                return true;
            default:
                return false;
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu,View view, ContextMenu.ContextMenuInfo contextMenuInfo)
    {
        super.onCreateContextMenu(menu,view,contextMenuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_context,menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.context_del:
                AlertDialog.Builder myAlertBuilder = new
                        AlertDialog.Builder(MainActivity.this);
                // Set the dialog title and message.
                myAlertBuilder.setTitle("Alert");
                myAlertBuilder.setMessage("Click OK to delete, or Cancel to not:");

                myAlertBuilder.setPositiveButton("OK", new
                        DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // User clicked OK button.

                                listItem.remove(postionINDEX);
                adapter = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1, listItem);
                lv.setAdapter(adapter);
                                Toast.makeText(getApplicationContext(), "Deleted successfully",
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
                myAlertBuilder.setNegativeButton("Cancel", new
                        DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // User cancelled the dialog.
                                Toast.makeText(getApplicationContext(), "Item not deleted",
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
//
//
                myAlertBuilder.show();
                return true;
        }
        return super.onContextItemSelected(item);
    }


}
