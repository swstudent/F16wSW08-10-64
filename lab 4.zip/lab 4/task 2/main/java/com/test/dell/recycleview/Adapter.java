package com.test.dell.recycleview;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class Adapter extends RecyclerView.Adapter<Adapter.Item>
{
    String[] items;

    public Adapter(String[] items)
    {
        // this.context=context;
        this.items=items;
    }
    @NonNull
    @Override
    public Item onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        View view = inflater.inflate(R.layout.list_item_layout,viewGroup,false);
        return new Item(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Item item, int i)
    {
        String title = items[i];
        item.textView.setText(title);
    }

    @Override
    public int getItemCount() {
        return items.length;
    }

    public class Item extends RecyclerView.ViewHolder
    {
        ImageView imageView;
        TextView textView;
        public Item(@NonNull View itemView)
        {
            super(itemView);

            imageView =(ImageView)itemView.findViewById(R.id.imageView);
            textView =(TextView) itemView.findViewById(R.id.textView);
        }
    }
}
